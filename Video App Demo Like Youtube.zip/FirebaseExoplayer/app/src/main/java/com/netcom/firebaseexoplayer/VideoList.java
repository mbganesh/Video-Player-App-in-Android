package com.netcom.firebaseexoplayer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class VideoList extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_list);

        recyclerView = findViewById(R.id.recyclerViewId);
       List<ModelClass> modelClasses = new ArrayList<>();
        modelClasses.add(new ModelClass("Create Custom Button (144p) " ,R.drawable.two , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/Custom%20Button_144P.mp4?alt=media&token=663a1e11-a9f4-4f8c-aa36-2c7f9d45f3fa" ));

        modelClasses.add(new ModelClass("m3u83      Not a Video" , R.drawable.three, "http://demo.unified-streaming.com/video/tears-of-steel/tears-of-steel.ism/.m3u83"));
        modelClasses.add(new ModelClass("Video No 1" , R.drawable.one , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/flash_files%2F1.mp4?alt=media&token=f2058485-f09b-4cf0-ba38-c77bdf2ac5a3"));
        modelClasses.add(new ModelClass("Video No 2" , R.drawable.two , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/flash_files%2F2.mp4?alt=media&token=1bfaa3c9-ab69-44b6-8641-3b396555bc2e"));
        modelClasses.add(new ModelClass("Video No 3" , R.drawable.three , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/flash_files%2F3.mp4?alt=media&token=d2433117-3ef3-4adf-ae56-1871b583ec9e"));
        modelClasses.add(new ModelClass("Video No 4" , R.drawable.one , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/flash_files%2Fone.mp4?alt=media&token=46173fe8-e46e-41c4-9aba-607b68321fd9"));
        modelClasses.add(new ModelClass("Video No 5" , R.drawable.two , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/flash_files%2Ftwo.mp4?alt=media&token=546390e8-16e5-4f8a-8264-c23b696f2cfb"));
        modelClasses.add(new ModelClass("Video No 6" , R.drawable.three , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/flash_files%2Fthree.mp4?alt=media&token=d738922b-e22f-4cfb-97fe-4b09bbd64ff3"));

        modelClasses.add(new ModelClass("720p " ,R.drawable.one , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/720P.mp4?alt=media&token=74b92594-dc23-44ee-82ef-3e59ca6442e1"));
        modelClasses.add(new ModelClass("Create Custom Button (144p) " ,R.drawable.two , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/Custom%20Button_144P.mp4?alt=media&token=663a1e11-a9f4-4f8c-aa36-2c7f9d45f3fa" ));
        modelClasses.add(new ModelClass("Create Custom Button (480p) " ,R.drawable.three , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/Custom%20Button_480p.mp4?alt=media&token=87e1989a-fc68-4a1a-a3fc-76177b45259f"));

//        modelClasses.add(new ModelClass("Escape Plan" , R.drawable.escape_plan , "https://bit.ly/3oU0uHm"));
//        modelClasses.add(new ModelClass("ManiFest Manually" , R.drawable.escape_plan , "https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/PDF%2Fplaylist.m3u8?alt=media&token=bc5165fb-9caa-462b-9293-d2558ca43f6a"));

        Adapter adapter = new Adapter(modelClasses, VideoList.class );
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }
}


